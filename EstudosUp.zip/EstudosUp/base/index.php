<?php
    include"../base/home.php";
    include"../base/rodape.php";
?>