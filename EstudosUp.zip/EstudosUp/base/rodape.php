<div id="body"></div>
<footer class="rodape">
	<font color="#FFF">
	<p>Desenvolvido por: <br>
	Renan dos Santos Fragaio e Júlio Cesar Júnior  -  Turma: 3251<br>
	Copyright Todos os direitos reservados </p></font>
</footer>
</div><!--holder-->
</body>
</html>