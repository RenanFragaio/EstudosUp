function deletaDado (idDado){
				//seta o caminho para quando clicar em "Sim".
				var href = "../usuario/excluir_usuario.php?id_usuario=" + idDado;
				//adiciona atributo de delecao ao link
				$('#confirmaDelecao').prop("href", href);
}